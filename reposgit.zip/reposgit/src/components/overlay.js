"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var components_1 = require("components");
var COMPARISON_MAX_ITEMS = 3;
var MapOverlay = (function (_super) {
    __extends(MapOverlay, _super);
    function MapOverlay() {
        var _this = _super.apply(this, arguments) || this;
        _this.wrapper = {
            type: 'div',
            id: 'map-overlay'
        };
        _this.legend = null;
        _this.sidebar = null;
        _this.comparison = [];
        _this.showLegend = function (data) {
            _this.removeLegend();
            if (_this.sidebar && _this.sidebar.data === data) {
                return;
            }
            _this.legend = new components_1.InfoBox(_this.root, data);
        };
        _this.removeLegend = function () {
            if (_this.legend) {
                _this.legend.remove();
                _this.legend = null;
            }
        };
        _this.showSidebar = function (data) {
            if (!_this.legend || _this.legend.data !== data) {
                _this.showLegend(data);
            }
            _this.removeSidebar();
            _this.sidebar = _this.legend;
            _this.sidebar.expand();
            _this.legend = null;
        };
        return _this;
    }
    MapOverlay.prototype.onResize = function (rect) {
        if (this.sidebar) {
            this.sidebar.resize(rect);
        }
        this.comparison.forEach(function (comparisonBox) { return comparisonBox.resize(rect); });
    };
    MapOverlay.prototype.removeSidebar = function () {
        if (this.sidebar) {
            this.sidebar.remove();
            this.sidebar = null;
        }
    };
    MapOverlay.prototype.canCompare = function (data) {
        if (this.comparison.length >= COMPARISON_MAX_ITEMS) {
            return false;
        }
        for (var _i = 0, _a = this.comparison; _i < _a.length; _i++) {
            var box = _a[_i];
            var target = data.properties;
            var boxData = box.data.properties;
            if (target.type === boxData.type &&
                target.name === boxData.name) {
                return false;
            }
        }
        return true;
    };
    MapOverlay.prototype.addToComparison = function (data, shape) {
        if (!this.sidebar || this.sidebar.data !== data) {
            throw 'This shouldn\'t happen';
        }
        var box = this.sidebar;
        this.sidebar = null;
        this.comparison.push(box);
        box.pin(shape);
    };
    MapOverlay.prototype.removeFromComparison = function (box) {
        this.comparison.splice(this.comparison.indexOf(box), 1);
        box.remove();
        if (this.sidebar && this.comparison.length === COMPARISON_MAX_ITEMS - 1) {
            this.sidebar.addComparisonButton();
        }
    };
    return MapOverlay;
}(components_1.ComponentBase));
exports.MapOverlay = MapOverlay;
//# sourceMappingURL=overlay.js.map