"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var components_1 = require("components");
require("../styles/info-box.scss");
var FADE_DURATION = 300;
var InfoBox = (function (_super) {
    __extends(InfoBox, _super);
    function InfoBox(root, data) {
        var _this = _super.call(this, root) || this;
        _this.data = data;
        _this.wrapper = {
            type: 'div',
            classes: ['info-box']
        };
        _this.state = 'legend';
        _this.remove = function () {
            _this.fadeOut();
        };
        _this.addComparisonButton = function () {
            _this.root
                .append('button')
                .classed('compare', true)
                .text('Compare with other region')
                .on('click', _this.app.compare);
        };
        _this.initDetails = function () {
            if (_this.data.properties.type !== 'region') {
                _this.title
                    .append('div')
                    .classed('subtitle', true)
                    .text(_this.getSubtitle);
            }
            _this.details = new components_1.InfoDetails(_this.root);
            _this.details.init();
            if (_this.app.overlay.canCompare(_this.data)) {
                _this.addComparisonButton();
            }
        };
        _this.init();
        return _this;
    }
    InfoBox.prototype.onInit = function () {
        var root = this.root
            .datum(this.data)
            .style('opacity', 0)
            .style('margin-top', '-20px');
        this.title = root
            .append('div')
            .classed('title', true)
            .text(function (d) { return d.properties.name; });
        this.fadeIn();
    };
    InfoBox.prototype.onResize = function (rect) {
        if (this.thumb) {
            this.thumb.resize(rect);
        }
        if (this.details) {
            this.details.resize(rect);
        }
    };
    InfoBox.prototype.expand = function () {
        this.state = 'sidebar';
        this.root.classed('expanded', true);
        setTimeout(this.initDetails, FADE_DURATION);
    };
    InfoBox.prototype.pin = function (shape) {
        var _this = this;
        this.root.classed('pinned', true);
        this.root
            .append('div')
            .classed('close', true)
            .text('×')
            .on('click', function () {
            _this.app.removeComparison(_this);
        });
        this.thumb = new components_1.InfoThumb(this.root);
        this.thumb.init();
    };
    InfoBox.prototype.fadeIn = function () {
        this.root
            .transition()
            .duration(FADE_DURATION)
            .style('opacity', 1)
            .style('margin-top', '0px');
    };
    InfoBox.prototype.fadeOut = function () {
        var _this = this;
        if (this.state === 'legend') {
            this.root
                .transition()
                .duration(FADE_DURATION)
                .style('opacity', 0)
                .style('margin-top', '32px')
                .on('end', function () { return _this.root.remove(); });
        }
        else {
            this.root.remove();
        }
    };
    InfoBox.prototype.getSubtitle = function (data) {
        var type = data.properties.type;
        var idx = components_1.LAYER_ORDER.indexOf(type);
        return data.properties[components_1.LAYER_ORDER[idx - 1]] || type;
    };
    return InfoBox;
}(components_1.ComponentBase));
exports.InfoBox = InfoBox;
//# sourceMappingURL=info-box.js.map