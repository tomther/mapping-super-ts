"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var d3 = require("d3");
require("styles/map.scss");
var components_1 = require("components");
exports.LAYER_ORDER = ['region', 'country', 'state'];
exports.ROTATION = [-11, 0];
var EQR_WIDTH = 640;
var ASPECT_RATIO = 2.57617729; // Approximated map aspect ratio after removing Antartica
var PRECISION = .05;
var ZOOM_DURATION = 600;
var MIN_SCALE = 0.3;
var MAX_SCALE = 48;
var Map = (function (_super) {
    __extends(Map, _super);
    function Map() {
        var _this = _super.apply(this, arguments) || this;
        _this.wrapper = { type: 'svg', id: 'map' };
        _this.layers = [];
        _this.layerIndex = 0;
        _this.leftBound = 0;
        _this.rightBound = 0;
        _this.onCameraAnimationStart = function () {
            _this.root.classed('animating', true);
        };
        _this.onCameraAnimationEnd = function () {
            _this.root.classed('animating', false);
        };
        _this.select = function (target, shape) {
            if (_this.selection) {
                _this.selection.shape.classed('selected', false);
                _this.selection.layer.root.classed('with-selection', false);
            }
            _this.layerIndex = exports.LAYER_ORDER.indexOf(target.properties.type);
            var layer = _this.layers[_this.layerIndex];
            shape.classed('selected', true);
            layer.root.classed('with-selection', true);
            _this.root.classed('with-selection', true);
            _this.selection = {
                data: target,
                shape: shape,
                layer: layer
            };
            _this.cameraFocus(target);
            _this.removeExtraLayers();
            if (_this.selection.data.properties.has_sublayer) {
                _this.initLayer(_this.layerIndex + 1, _this.selection);
            }
        };
        _this.clearSelection = function () {
            if (_this.selection) {
                _this.selection.shape.classed('selected', false);
                _this.selection.layer.root.classed('with-selection', false);
            }
            _this.root.classed('with-selection', false);
            _this.layerIndex = 0;
            _this.selection = null;
            _this.cameraFocus(_this.worldLand);
            _this.removeExtraLayers();
        };
        _this.cameraFocus = function (feature) {
            _this.cameraAdjustBounds();
            var width = _this.rect.width - _this.leftBound - _this.rightBound;
            var margin = .05;
            var height = _this.rect.height;
            var center = _this.leftBound + width / 2;
            var transforms = _this.fitGeometry(feature, width, height, margin, center);
            var transformation = d3.zoomIdentity
                .translate(transforms.translate[0], transforms.translate[1])
                .scale(transforms.scale);
            _this.onCameraAnimationStart();
            _this.root.transition()
                .duration(ZOOM_DURATION)
                .call(_this.zoom.transform, transformation)
                .on('end', _this.onCameraAnimationEnd);
        };
        return _this;
    }
    Map.prototype.onInit = function () {
        this.projection = d3.geoEquirectangular()
            .rotate(exports.ROTATION)
            .precision(PRECISION);
        this.path = d3.geoPath()
            .projection(this.projection);
        this.initBaseLayers();
        var layersRoot = this.layersRoot;
        components_1.MapLayer.parentComponent = this;
        this.zoom = d3.zoom()
            .scaleExtent([1, MAX_SCALE])
            .on('zoom', function () {
            layersRoot.attr('transform', d3.event.transform);
        });
        this.initLayer(this.layerIndex);
    };
    Map.prototype.onResize = function (rect) {
        // Blank space left in projection due to removal of Antartica
        var blankSpace = rect.height - (rect.width / ASPECT_RATIO);
        this.projection
            .scale((rect.width / EQR_WIDTH) * 100)
            .translate([
            rect.width / 2,
            (rect.height + (blankSpace / 2)) / 2
        ]);
        this.layers.forEach(function (l) { return l.resize(rect); });
        this.cameraRefresh();
    };
    Map.prototype.initBaseLayers = function () {
        var ocean = this.root
            .append('rect')
            .classed('ocean', true)
            .on('click', this.app.deselect);
        this.layersRoot = this.root
            .append('g')
            .classed('layers', true);
        this.worldLand = this.app.data.getFeatures('world').features[0];
        this.addResizer(function (rect) {
            ocean
                .attr('width', rect.width)
                .attr('height', rect.height);
        });
    };
    Map.prototype.initLayer = function (index, context) {
        if (!this.layers[index]) {
            var layerType = exports.LAYER_ORDER[index];
            this.layers[index] = new components_1.MapLayer(layerType, context);
        }
        return this.layers[index];
    };
    Map.prototype.removeExtraLayers = function () {
        var _this = this;
        this.layers = this.layers.filter(function (layer, idx) {
            var selection = _this.selection ? _this.selection.data : false;
            var isDirectChild = layer.parent && layer.parent.data === selection;
            var isBelowCurrent = idx > _this.layerIndex;
            if ((isBelowCurrent && !isDirectChild) || (!selection && idx > 0)) {
                layer.destroy();
                return false;
            }
            else {
                return true;
            }
        });
    };
    Map.prototype.cameraRefresh = function () {
        if (this.selection) {
            this.cameraFocus(this.selection.data);
        }
        else {
            this.cameraFocus(this.worldLand);
        }
    };
    Map.prototype.fitGeometry = function (geometry, width, height, margin, center) {
        if (margin === void 0) { margin = 0; }
        if (!center) {
            center = width / 2;
        }
        var bounds = this.path.bounds(geometry), dx = bounds[1][0] - bounds[0][0], dy = bounds[1][1] - bounds[0][1], x = (bounds[0][0] + bounds[1][0]) / 2, y = (bounds[0][1] + bounds[1][1]) / 2, scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, (1 - margin) / Math.max(dx / width, dy / height))), translate = [center - scale * x, height / 2 - scale * y];
        return { scale: scale, translate: translate };
    };
    Map.prototype.cameraAdjustBounds = function () {
        var sidebar = d3.select('.info-box.expanded:not(.pinned)').node();
        var panels = d3.selectAll('.info-box.pinned').nodes();
        this.rightBound = 0;
        this.leftBound = 0;
        if (sidebar) {
            var sidebarRect = sidebar.getBoundingClientRect();
            var sidebarMargin = this.rect.right - sidebarRect.right;
            this.rightBound += sidebarRect.width + sidebarMargin;
        }
        if (panels.length) {
            var panelRect = panels[0].getBoundingClientRect();
            this.leftBound += panelRect.width * panels.length;
        }
    };
    return Map;
}(components_1.ComponentBase));
exports.Map = Map;
//# sourceMappingURL=map.js.map