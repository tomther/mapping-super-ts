"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
require("../styles/info-details.scss");
var components_1 = require("components");
var InfoDetails = (function (_super) {
    __extends(InfoDetails, _super);
    function InfoDetails() {
        var _this = _super.apply(this, arguments) || this;
        _this.wrapper = {
            type: 'div',
            classes: ['details']
        };
        _this.onDataLoaded = function (data) {
            _this.root.html('Data Loaded');
            /*let scale = d3.scaleLinear()
                .domain([0, d3.max(data.sample, d => d.value)])
                .range([0, 100])
            
            this.root.html('Sample Chart')
            
            let bars = this.root.selectAll('.bar')
                .data(data.sample)
                .enter()
                .append('div')
                .classed('bar', true)
                .style('width', '0%')
            
            bars.transition()
                .duration(600)
                .ease(d3.easeExpOut)
                .style('width', d => scale(d.value) + '%')*/
        };
        return _this;
    }
    InfoDetails.prototype.onInit = function () {
        this.root.html('Loading...');
        var data = this.host.datum();
        this.app.data.fetchDetails(data, this.onDataLoaded);
    };
    return InfoDetails;
}(components_1.ComponentBase));
exports.InfoDetails = InfoDetails;
//# sourceMappingURL=info-details.js.map