"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var d3 = require("d3");
require("../styles/info-thumb.scss");
var components_1 = require("components");
var InfoThumb = (function (_super) {
    __extends(InfoThumb, _super);
    function InfoThumb() {
        var _this = _super.apply(this, arguments) || this;
        _this.wrapper = {
            type: 'svg',
            classes: ['thumb'],
            before: '.title'
        };
        return _this;
    }
    InfoThumb.prototype.onInit = function () {
        var _this = this;
        this.projection = d3
            .geoEquirectangular()
            .rotate(components_1.ROTATION);
        var path = d3.geoPath()
            .projection(this.projection);
        var data = this.host.datum();
        var host = this.root.node();
        var shapeRoot = this.root.append('g');
        var shape = shapeRoot
            .append('path')
            .datum(data)
            .style('color', function (d) { return d.properties.color; });
        this.addResizer(function () {
            var rect = host.getBoundingClientRect();
            _this.projection.fitSize([rect.width, rect.height], data);
            shape.attr('d', path);
        }, true);
    };
    return InfoThumb;
}(components_1.ComponentBase));
exports.InfoThumb = InfoThumb;
//# sourceMappingURL=info-thumb.js.map