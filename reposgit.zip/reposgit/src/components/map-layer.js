"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var components_1 = require("components");
var ANIMATION_DURATION = 300;
var MapLayer = (function (_super) {
    __extends(MapLayer, _super);
    function MapLayer(type, parent) {
        var _this = _super.call(this, MapLayer.parentComponent.layersRoot) || this;
        _this.type = type;
        _this.parent = parent;
        _this.map = MapLayer.parentComponent;
        _this.wrapper = {
            type: 'g',
            classes: ['layer', type]
        };
        _this.init();
        return _this;
    }
    MapLayer.prototype.onInit = function () {
        var _this = this;
        var contextData = this.parent ? this.parent.data.properties : undefined;
        var shapesData = this.app.data.getFeatures(this.type, contextData);
        var boundaryData = this.app.data.getMesh(this.type, contextData);
        var childs = this.root
            .selectAll('g')
            .data(shapesData.features)
            .enter()
            .append('g')
            .classed('land', true)
            .attr('data-name', function (d) { return d.properties.name; });
        var selectionCallback = this.app.select;
        var shapes = childs
            .append('path')
            .style('color', this.app.data.getColor)
            .on('click', function (feature) {
            selectionCallback(feature, this);
        })
            .on('mouseenter', this.app.overlay.showLegend)
            .on('mouseleave', this.app.overlay.removeLegend);
        var boundaries = this.root
            .append('g')
            .classed('boundaries', true)
            .append('path')
            .style('opacity', 0)
            .attr('vector-effect', 'non-scaling-stroke')
            .datum(boundaryData);
        boundaries
            .transition()
            .duration(ANIMATION_DURATION / 2)
            .style('opacity', 1);
        this.addResizer(function () {
            shapes.attr('d', _this.map.path);
            boundaries.attr('d', _this.map.path);
        }, this.parent !== undefined);
    };
    MapLayer.prototype.destroy = function () {
        this.root.remove();
    };
    return MapLayer;
}(components_1.ComponentBase));
exports.MapLayer = MapLayer;
//# sourceMappingURL=map-layer.js.map