"use strict";
var ComponentBase = (function () {
    function ComponentBase(root) {
        this.root = root;
        this.relative = false;
        this.resizers = [];
        this.host = root;
    }
    Object.defineProperty(ComponentBase.prototype, "app", {
        get: function () {
            return window['app'];
        },
        enumerable: true,
        configurable: true
    });
    ComponentBase.prototype.onInit = function () { };
    ComponentBase.prototype.onResize = function (rect) { };
    ComponentBase.prototype.init = function () {
        var _this = this;
        this.applyOptions(this.wrapper, {
            'type': function (t) {
                var b = _this.wrapper.before;
                if (b) {
                    _this.root = _this.root.insert(t, b);
                }
                else {
                    _this.root = _this.root.append(t);
                }
            },
            'classes': function (c) {
                c.forEach(function (name) { return _this.root.classed(name, true); });
            },
            'id': function (i) {
                _this.root.attr('id', i);
            }
        });
        this.onInit();
    };
    ComponentBase.prototype.resize = function (appRect) {
        var rect = appRect;
        if (this.relative) {
            var rootEl = this.root.node();
            rect = rootEl.getBoundingClientRect();
        }
        this.rect = rect;
        this.onResize(rect);
        this.resizers.forEach(function (r) { return r(rect); });
    };
    ComponentBase.prototype.addResizer = function (resizer, execute) {
        if (execute === void 0) { execute = false; }
        this.resizers.push(resizer);
        if (execute) {
            resizer(this.rect);
        }
    };
    ComponentBase.prototype.applyOptions = function (options, appliers) {
        if (!options) {
            return;
        }
        for (var optionName in appliers) {
            if (optionName in options) {
                appliers[optionName](options[optionName]);
            }
        }
    };
    return ComponentBase;
}());
exports.ComponentBase = ComponentBase;
//# sourceMappingURL=component-base.js.map